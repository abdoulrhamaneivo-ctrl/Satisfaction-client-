// src/server/jobs/index.ts
// Exports centralisés des jobs cron Yeba

export { detecterAlertesSilence } from './alerteSilence';
export { relancerTachesEnRetard } from './relanceTache';
export { envoyerRapportsMensuels } from './rapportMensuel';
export { archiverElementsResolusAnciens } from './archivageAutomatique';
