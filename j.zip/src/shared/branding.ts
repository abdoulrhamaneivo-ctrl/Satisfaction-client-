export const BRANDING = {
  platform_name: "Yéba",
  platform_description: "Plateforme de collecte et de pilotage de la satisfaction client au guichet",
  logo_url: "/yeba-logo.svg",
  logo_dark_url: null,

  favicon_url: null,

  /* ── Palette Mode Clair (défaut) ──
     Fond crème + vert postal + jaune doré.
     Ces valeurs sont injectées par BrandContext dans :root:not(.dark). */
  color_background: "40 30% 96%",
  color_foreground: "216 40% 12%",
  color_card: "0 0% 100%",
  color_card_foreground: "216 40% 12%",
  color_popover: "0 0% 100%",
  color_popover_foreground: "216 40% 12%",
  color_primary: "149 100% 33%",
  color_primary_foreground: "0 0% 100%",
  color_secondary: "148 100% 26%",
  color_secondary_foreground: "0 0% 98%",
  color_secondary_muted: "149 30% 90%",
  color_secondary_muted_foreground: "216 53% 24%",
  color_accent: "149 60% 92%",
  color_accent_foreground: "149 90% 26%",
  color_muted: "216 16% 93%",
  color_muted_foreground: "216 14% 42%",
  color_destructive: "0 72% 51%",
  color_destructive_foreground: "0 0% 98%",
  color_success: "149 80% 34%",
  color_success_foreground: "0 0% 98%",
  color_warning: "45 100% 50%",
  color_warning_foreground: "216 40% 12%",
  color_border: "216 16% 88%",
  color_input: "216 16% 84%",
  color_ring: "149 100% 33%",
  border_radius: "0.75rem",
  shadow_style: "DEFAULT",
  font_family: "Satoshi",
  font_url: null,
  form_title: "Votre avis compte !",
  form_subtitle: "Notez-nous en 10 secondes après votre passage",
  form_thank_you: "Merci pour votre avis !",
  qr_slogan: "Scannez ce QR Code",
  ussd_help_text: "Pas de connexion internet ?",
  hide_yeba_branding: false,
};

export type BrandConfigType = typeof BRANDING;
